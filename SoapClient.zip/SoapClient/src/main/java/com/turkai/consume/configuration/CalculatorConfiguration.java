package com.turkai.consume.configuration;


public class CalculatorConfiguration {



}

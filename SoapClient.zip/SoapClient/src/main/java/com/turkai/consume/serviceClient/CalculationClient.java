package com.turkai.consume.serviceClient;


import org.springframework.ws.client.core.support.WebServiceGatewaySupport;


public class CalculationClient extends WebServiceGatewaySupport {









}

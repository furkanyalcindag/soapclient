package com.turkai.consume;

import com.turkai.consume.services.SoapService;
import com.turkai.consume.soapEntity.SoapChildElement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.SOAPException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class ConsumeApplication {

    public static void main(String[] args) throws SAXException, ParserConfigurationException, SOAPException, IOException {
        SpringApplication.run(ConsumeApplication.class, args);

        String soapEndpointUrl = "https://www.ulker.com.tr/webservices/contactservice/contactservice.asmx?WSDL";
        String soapAction = "http://tempuri.org/getIlcelerByIlId";

        //callSoapWebService(soapEndpointUrl, soapAction);

        SoapService soapService = new SoapService();

        List<SoapChildElement> childElements = new ArrayList<>();


        SoapChildElement soapChildElement2 = new SoapChildElement();
        soapChildElement2.setKey("ilId");
        soapChildElement2.setValue("44");


       /* SoapChildElement soapChildElement3 = new SoapChildElement();
        soapChildElement3.setKey("intB");
        soapChildElement3.setValue("23");*/


        childElements.add(soapChildElement2);
       // childElements.add(soapChildElement3);


        soapService.callSoapWebService(soapEndpointUrl, soapAction, "soapenv", "tem", "http://tempuri.org/", childElements, "getIlcelerByIlId");


        soapService.parseWsdl();





    }




}
